import React, { useState, useRef, useEffect } from 'react';
import { RotateCcw, Check, X, Loader, AlertCircle, Mic, MicOff, SwitchCamera, Upload } from 'lucide-react';
import TagSelector from './TagSelector';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { getSupportedMimeType, getVideoConstraints, isWebRTCSupported, formatFileSize } from '@/utils/videoHelpers';
import { Slider } from '@/components/ui/slider';

interface MemoryCaptureProps {
  onSave: (memory: any) => void;
  onBack: () => void;
  user: any;
}


const MemoryCapture: React.FC<MemoryCaptureProps> = ({ onSave, onBack, user }) => {

  const [isRecording, setIsRecording] = useState(false);
  const [countdown, setCountdown] = useState(10);
  const [showPreview, setShowPreview] = useState(false);
  const [showTagSelector, setShowTagSelector] = useState(false);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [recordedUrl, setRecordedUrl] = useState<string | null>(null);
  const [cameraPermission, setCameraPermission] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [isLoading, setIsLoading] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [cameraReady, setCameraReady] = useState(false);
  const [isMobile] = useState(/iPhone|iPad|iPod|Android/i.test(navigator.userAgent));
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>(
    /iPhone|iPad|iPod|Android/i.test(navigator.userAgent) ? 'environment' : 'user'
  );

  // Upload + trim (10s) state
  const [showUploadTrim, setShowUploadTrim] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadUrl, setUploadUrl] = useState<string | null>(null);
  const [uploadDuration, setUploadDuration] = useState<number>(0);
  const [trimStartSeconds, setTrimStartSeconds] = useState<number>(0);
  const [isTrimming, setIsTrimming] = useState(false);
  const [trimProgress, setTrimProgress] = useState<number>(0);

  
  const videoRef = useRef<HTMLVideoElement>(null);
  const uploadVideoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const animationFrameRef = useRef<number | null>(null);

  
  const { toast } = useToast();

  // Initialize camera on mount
  useEffect(() => {
    initializeCamera();
    return () => {
      stopCamera();
      if (uploadUrl) URL.revokeObjectURL(uploadUrl);
    };
  }, []);

  // Revoke upload URL when changed
  useEffect(() => {
    return () => {
      if (uploadUrl) URL.revokeObjectURL(uploadUrl);
    };
  }, [uploadUrl]);

  // Countdown timer
  useEffect(() => {
    if (isRecording && countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else if (isRecording && countdown === 0) {
      stopRecording();
    }
  }, [isRecording, countdown]);

  const initializeCamera = async () => {
    if (!isWebRTCSupported()) {
      setCameraPermission('denied');
      toast({
        title: "Browser Not Supported",
        description: "Your browser doesn't support video recording. Please use a modern browser.",
        variant: "destructive"
      });
      return;
    }

    try {
      const constraints = getVideoConstraints(facingMode);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: constraints,
        audio: audioEnabled
      });
      
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.muted = true;
      }
      setCameraPermission('granted');
      setCameraReady(true);
    } catch (error) {
      console.error('Camera access error:', error);
      setCameraPermission('denied');
      toast({
        title: "Camera Access Required",
        description: "Please allow camera access to record memories",
        variant: "destructive"
      });
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  const switchCamera = async () => {
    stopCamera();
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
    setCameraReady(false);
    
    try {
      const constraints = getVideoConstraints(facingMode === 'user' ? 'environment' : 'user');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: constraints,
        audio: audioEnabled
      });
      
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.muted = true;
      }
      setCameraReady(true);
    } catch (error) {
      console.error('Camera switch error:', error);
      // Fallback to original camera if switch fails
      setFacingMode('user');
      initializeCamera();
    }
  };

  const toggleAudio = () => {
    if (streamRef.current) {
      const audioTracks = streamRef.current.getAudioTracks();
      audioTracks.forEach(track => {
        track.enabled = !audioEnabled;
      });
      setAudioEnabled(!audioEnabled);
    }
  };

  const openUploadPicker = () => {
    // Stop camera preview to save resources while user is choosing a file.
    stopCamera();
    fileInputRef.current?.click();
  };

  const loadVideoDuration = (fileUrl: string): Promise<number> => {
    return new Promise((resolve, reject) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.src = fileUrl;
      video.onloadedmetadata = () => {
        const dur = Number.isFinite(video.duration) ? video.duration : 0;
        resolve(dur);
      };
      video.onerror = () => reject(new Error('Failed to read video metadata'));
    });
  };

  const onUploadFileSelected: React.ChangeEventHandler<HTMLInputElement> = async (e) => {
    const file = e.target.files?.[0];
    // Reset input value so selecting the same file again still fires change.
    e.target.value = '';
    if (!file) {
      // If they cancel the picker, restore camera.
      initializeCamera();
      return;
    }

    if (!file.type.startsWith('video/')) {
      toast({
        title: 'Not a video',
        description: 'Please select a video file from your library.',
        variant: 'destructive'
      });
      initializeCamera();
      return;
    }

    const url = URL.createObjectURL(file);
    setUploadFile(file);
    setUploadUrl(url);
    setTrimProgress(0);
    setIsTrimming(false);
    setShowUploadTrim(true);

    try {
      const duration = await loadVideoDuration(url);
      setUploadDuration(duration);
      // Clamp start to a valid range.
      const maxStart = Math.max(0, duration - 10);
      setTrimStartSeconds(prev => Math.min(prev, maxStart));
    } catch (err) {
      console.error(err);
      toast({
        title: 'Couldn\'t read video',
        description: 'Please try a different video file.',
        variant: 'destructive'
      });
      setShowUploadTrim(false);
      setUploadFile(null);
      if (url) URL.revokeObjectURL(url);
      setUploadUrl(null);
      initializeCamera();
    }
  };

  const cancelUploadTrim = () => {
    setShowUploadTrim(false);
    setUploadFile(null);
    if (uploadUrl) URL.revokeObjectURL(uploadUrl);
    setUploadUrl(null);
    setUploadDuration(0);
    setTrimStartSeconds(0);
    setTrimProgress(0);
    setIsTrimming(false);
    initializeCamera();
  };

  const startRecording = async () => {
    if (!streamRef.current) {
      await initializeCamera();
    }
    
    if (!streamRef.current || !videoRef.current) return;
    
    chunksRef.current = [];
    
    // Set recording state first
    setIsRecording(true);
    setCountdown(10);
    
    // Determine if we should flip the video (only for front camera)
    const shouldFlip = facingMode === 'user';
    
    // Create canvas for processing video
    const canvas = document.createElement('canvas');
    const video = videoRef.current;
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    canvasRef.current = canvas;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    let isDrawing = true;
    
    // Function to draw video frame (flipped or normal)
    const drawFrame = () => {
      if (!isDrawing) return;
      
      ctx.save();
      if (shouldFlip) {
        ctx.scale(-1, 1);
        ctx.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
      } else {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      }
      ctx.restore();
      
      animationFrameRef.current = requestAnimationFrame(drawFrame);
    };
    
    // Start drawing frames
    drawFrame();
    
    // Get stream from canvas
    const canvasStream = canvas.captureStream(30); // 30 fps
    
    // Add audio track from original stream if audio is enabled
    if (audioEnabled) {
      const audioTracks = streamRef.current.getAudioTracks();
      audioTracks.forEach(track => canvasStream.addTrack(track));
    }
    
    const mimeType = getSupportedMimeType();
    const options: MediaRecorderOptions = {
      mimeType,
      videoBitsPerSecond: isMobile ? 1500000 : 2500000
    };
    
    try {
      const mediaRecorder = new MediaRecorder(canvasStream, options);
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };
      
      mediaRecorder.onstop = () => {
        // Stop animation frame
        isDrawing = false;
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
          animationFrameRef.current = null;
        }
        
        const blob = new Blob(chunksRef.current, { type: mimeType });
        setRecordedBlob(blob);
        const url = URL.createObjectURL(blob);
        setRecordedUrl(url);
        setShowPreview(true);
        stopCamera();
        
        // Show file size in console for debugging
        console.log('Recorded video size:', formatFileSize(blob.size));
      };
      
      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start(1000); // Capture data every second
    } catch (error) {
      console.error('Failed to start recording:', error);
      toast({
        title: "Recording Failed",
        description: "Unable to start recording. Please try again.",
        variant: "destructive"
      });
      setIsRecording(false);
    }
  };




  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const retake = () => {
    setShowPreview(false);
    setRecordedBlob(null);
    if (recordedUrl) {
      URL.revokeObjectURL(recordedUrl);
      setRecordedUrl(null);
    }
    setCountdown(10);
    initializeCamera();
  };

  const openFilePicker = () => {
    fileInputRef.current?.click();
  };

  const handleFilePicked = async (file: File | null) => {
    if (!file) return;

    if (!file.type.startsWith('video/')) {
      toast({
        title: 'Not a video file',
        description: 'Please choose a video from your library.',
        variant: 'destructive'
      });
      return;
    }

    // Stop camera if it was running (saves battery / avoids permissions weirdness)
    stopCamera();
    setCameraReady(false);

    // Create local preview
    const url = URL.createObjectURL(file);
    setUploadFile(file);
    setUploadUrl(url);
    setShowUploadTrim(true);
    setTrimStartSeconds(0);
    setTrimProgress(0);

    // Load duration
    const duration = await new Promise<number>((resolve) => {
      const v = document.createElement('video');
      v.preload = 'metadata';
      v.onloadedmetadata = () => {
        resolve(Number.isFinite(v.duration) ? v.duration : 0);
      };
      v.onerror = () => resolve(0);
      v.src = url;
    });
    setUploadDuration(duration);

    if (duration > 0) {
      const maxStart = Math.max(0, duration - 10);
      setTrimStartSeconds(0);
      // If the video is shorter than 10 seconds, we can still accept it,
      // but we will warn the user that we'll export whatever exists (up to 10s).
      if (duration < 10) {
        toast({
          title: 'Short video',
          description: 'This video is under 10 seconds. We will save the whole clip as your Momento.'
        });
      } else if (maxStart === 0) {
        // Exactly 10 seconds
        toast({
          title: 'Perfect length',
          description: 'This video is already 10 seconds.'
        });
      }
    }
  };

  const cancelUploadTrim = () => {
    setShowUploadTrim(false);
    setUploadFile(null);
    if (uploadUrl) URL.revokeObjectURL(uploadUrl);
    setUploadUrl(null);
    setUploadDuration(0);
    setTrimStartSeconds(0);
    setTrimProgress(0);
    // Return to camera
    initializeCamera();
  };

  const confirmTrimToTenSeconds = async () => {
    if (!uploadFile) return;

    try {
      setIsTrimming(true);
      setTrimProgress(0);

      // We "trim" by re-recording a 10-second window from the selected video using
      // the browser's MediaRecorder. This avoids heavyweight FFmpeg WASM dependencies.
      const videoEl = uploadVideoRef.current;
      if (!videoEl) throw new Error('Upload preview video not available');

      // Ensure the video element has the file loaded
      if (!videoEl.src) videoEl.src = uploadUrl || '';

      // Wait for metadata so we can seek reliably
      await new Promise<void>((resolve, reject) => {
        if (videoEl.readyState >= 1) return resolve();
        const onLoaded = () => {
          cleanup();
          resolve();
        };
        const onError = () => {
          cleanup();
          reject(new Error('Could not load video for trimming'));
        };
        const cleanup = () => {
          videoEl.removeEventListener('loadedmetadata', onLoaded);
          videoEl.removeEventListener('error', onError);
        };
        videoEl.addEventListener('loadedmetadata', onLoaded);
        videoEl.addEventListener('error', onError);
      });

      // If shorter than 10 seconds, accept as-is.
      if (uploadDuration > 0 && uploadDuration < 10) {
        const blob = new Blob([await uploadFile.arrayBuffer()], { type: uploadFile.type });
        const url = URL.createObjectURL(blob);
        setRecordedBlob(blob);
        setRecordedUrl(url);
        setShowUploadTrim(false);
        setShowPreview(true);
        return;
      }

      // Seek to start
      const start = Math.max(0, trimStartSeconds);
      await new Promise<void>((resolve) => {
        const onSeeked = () => {
          videoEl.removeEventListener('seeked', onSeeked);
          resolve();
        };
        videoEl.addEventListener('seeked', onSeeked);
        videoEl.currentTime = start;
      });

      // Capture the stream and record 10 seconds
      const captureFn = (videoEl as any).captureStream || (videoEl as any).mozCaptureStream;
      if (!captureFn) throw new Error('Your browser does not support video capture. Try Chrome or Edge.');

      const capturedStream: MediaStream = captureFn.call(videoEl);
      const mimeType = getSupportedMimeType();
      const recorder = new MediaRecorder(capturedStream, { mimeType });
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) chunks.push(ev.data);
      };

      const clipBlob: Blob = await new Promise((resolve, reject) => {
        recorder.onstop = () => {
          try {
            videoEl.pause();
            // Stop tracks to free resources
            capturedStream.getTracks().forEach(t => t.stop());
          } catch {
            // noop
          }
          resolve(new Blob(chunks, { type: mimeType }));
        };
        recorder.onerror = () => reject(new Error('Recording failed while clipping.'));

        // Start recording and playback
        recorder.start(250);
        void videoEl.play();

        // Stop after 10 seconds
        window.setTimeout(() => {
          if (recorder.state !== 'inactive') recorder.stop();
        }, 10_000);
      });

      const url = URL.createObjectURL(clipBlob);
      setRecordedBlob(clipBlob);
      setRecordedUrl(url);
      setShowUploadTrim(false);
      setShowPreview(true);
    } catch (error: any) {
      console.error('Trim failed:', error);
      toast({
        title: 'Trim failed',
        description: error?.message || 'Unable to clip this video. Try a different file or browser.',
        variant: 'destructive'
      });
    } finally {
      setIsTrimming(false);
    }
  };

  const confirmVideo = () => {
    setShowTagSelector(true);
  };

  const handleTagsSelected = async (tags: string[]) => {
    if (!recordedBlob || !user) return;
    
    setIsLoading(true);
    
    try {
      // Generate unique filename
      const timestamp = Date.now();
      const ext = recordedBlob.type === 'video/mp4' ? 'mp4' : (recordedBlob.type.includes('webm') ? 'webm' : 'bin');
      const videoFileName = `${user.id}/${timestamp}.${ext}`;
      
      // Upload video to Supabase storage
      const { data: videoData, error: videoError } = await supabase.storage
        .from('user-videos')
        .upload(videoFileName, recordedBlob, {
          contentType: recordedBlob.type,
          upsert: false
        });

      if (videoError) throw videoError;

      // Get public URL for the video
      const { data: { publicUrl } } = supabase.storage
        .from('user-videos')
        .getPublicUrl(videoFileName);

      // Save memory to database
      const { data: memoryData, error: memoryError } = await supabase
        .from('memories')
        .insert({
          user_id: user.id,
          title: tags.length > 0 ? `${tags[0]} Memory` : 'Untitled Memory',
          video_url: publicUrl,
          tags: tags,
          is_favorite: false
        })
        .select()
        .single();

      if (memoryError) throw memoryError;

      toast({
        title: "Memory Saved!",
        description: "Your memory has been captured successfully"
      });
      
      if (recordedUrl) URL.revokeObjectURL(recordedUrl);
      onSave(memoryData);
      
    } catch (error: any) {
      console.error('Error saving memory:', error);
      toast({
        title: "Save Failed",
        description: error.message || "Failed to save memory. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };



  if (showTagSelector && recordedBlob) {
    return <TagSelector onSelect={handleTagsSelected} onBack={() => setShowTagSelector(false)} />;
  }

  // Upload + Trim screen
  if (showUploadTrim && uploadUrl) {
    const maxStart = uploadDuration > 10 ? Math.max(0, uploadDuration - 10) : 0;
    const endSeconds = uploadDuration > 0 ? Math.min(uploadDuration, trimStartSeconds + 10) : trimStartSeconds + 10;

    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black flex items-center justify-center p-4">
        <div className="w-full max-w-2xl">
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={cancelUploadTrim}
              className="p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
              disabled={isTrimming}
            >
              <X className="w-6 h-6 text-white" />
            </button>
            <h1 className="text-2xl font-bold text-white">Upload Memory</h1>
            <div className="w-12" />
          </div>

          <div className="relative bg-black rounded-3xl overflow-hidden aspect-[9/16] max-h-[70vh] mx-auto">
            <video
              ref={uploadVideoRef}
              src={uploadUrl}
              controls
              playsInline
              className="absolute inset-0 w-full h-full object-cover"
            />

            {isTrimming && (
              <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center gap-4 p-8">
                <Loader className="w-10 h-10 text-white animate-spin" />
                <div className="text-white/80 text-sm">Clipping your 10-second Momento…</div>
                <div className="w-full max-w-sm bg-white/10 rounded-full h-2 overflow-hidden">
                  <div className="h-2 bg-coral-500" style={{ width: `${Math.round(trimProgress * 100)}%` }} />
                </div>
              </div>
            )}
          </div>

          <div className="mt-6 bg-white/5 border border-white/10 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="text-white font-semibold">Select the 10 seconds to keep</div>
              {uploadDuration > 0 && (
                <div className="text-white/60 text-sm">Video length: {uploadDuration.toFixed(1)}s</div>
              )}
            </div>
            <div className="text-white/70 text-sm mb-4">
              Start: <span className="text-white">{trimStartSeconds.toFixed(1)}s</span> • End: <span className="text-white">{endSeconds.toFixed(1)}s</span>
            </div>

            {uploadDuration > 10 ? (
              <Slider
                value={[trimStartSeconds]}
                min={0}
                max={maxStart}
                step={0.1}
                onValueChange={(v) => {
                  const next = v?.[0] ?? 0;
                  setTrimStartSeconds(next);
                  // Keep preview roughly aligned
                  if (uploadVideoRef.current) {
                    uploadVideoRef.current.currentTime = next;
                  }
                }}
                disabled={isTrimming}
              />
            ) : (
              <div className="text-white/60 text-sm">
                This clip is already 10 seconds (or shorter). You can save it as-is.
              </div>
            )}

            <div className="flex gap-3 mt-4">
              <button
                onClick={cancelUploadTrim}
                className="flex-1 px-6 py-3 bg-white/10 backdrop-blur text-white rounded-full font-semibold hover:bg-white/20 transition-colors"
                disabled={isTrimming}
              >
                Cancel
              </button>
              <button
                onClick={confirmTrimToTenSeconds}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-coral-500 to-coral-600 text-white rounded-full font-semibold hover:from-coral-600 hover:to-coral-700 transition-colors"
                disabled={isTrimming}
              >
                {isTrimming ? 'Clipping…' : 'Use This 10s Clip'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
          
          <h1 className="text-2xl font-bold text-white">Capture Memory</h1>
          
          <button
            onClick={toggleAudio}
            className="p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
            disabled={showPreview}
          >
            {audioEnabled ? (
              <Mic className="w-6 h-6 text-white" />
            ) : (
              <MicOff className="w-6 h-6 text-white" />
            )}
          </button>
        </div>

        {/* Camera View */}
        <div className="relative bg-black rounded-3xl overflow-hidden aspect-[9/16] max-h-[70vh] mx-auto">
          {!showPreview ? (
            <>
              {/* Live Camera Feed */}
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="absolute inset-0 w-full h-full object-cover"
                style={{ transform: facingMode === 'user' ? 'scaleX(-1)' : 'none' }}
              />





              
              {/* Camera Permission Denied */}
              {cameraPermission === 'denied' && (
                <div className="absolute inset-0 bg-gray-900 flex flex-col items-center justify-center p-8">
                  <AlertCircle className="w-16 h-16 text-red-500 mb-4" />
                  <p className="text-white text-center mb-2">Camera access denied</p>
                  <p className="text-white/60 text-sm text-center">
                    Please enable camera access in your browser settings to record memories
                  </p>
                </div>
              )}
              
              
              {/* Switch Camera Button (Mobile Only) */}
              {isMobile && cameraReady && !isRecording && (
                <button
                  onClick={switchCamera}
                  className="absolute top-4 right-4 p-3 bg-white/10 backdrop-blur rounded-full hover:bg-white/20 transition-colors"
                >
                  <SwitchCamera className="w-5 h-5 text-white" />
                </button>
              )}
              
              {/* Recording Indicator */}
              {isRecording && (
                <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-600 px-3 py-1 rounded-full">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  <span className="text-white font-semibold">REC</span>
                </div>
              )}
              
              {/* Countdown */}
              {isRecording && (
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="text-8xl font-bold text-white animate-pulse drop-shadow-2xl">
                    {countdown}
                  </div>
                </div>
              )}
              
              {/* Progress Bar */}
              {isRecording && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
                  <div 
                    className="h-full bg-coral-500 transition-all duration-1000"
                    style={{ width: `${((10 - countdown) / 10) * 100}%` }}
                  />
                </div>
              )}
            </>
          ) : (
            <>
              {/* Video Preview */}
              {recordedUrl && (
                <video
                  src={recordedUrl}
                  autoPlay
                  loop
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover"
                />
              )}

              
              {/* Preview Controls */}
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent">
                <div className="flex justify-center gap-4">
                  <button
                    onClick={retake}
                    className="px-6 py-3 bg-white/20 backdrop-blur text-white rounded-full font-semibold hover:bg-white/30 transition-colors flex items-center gap-2"
                    disabled={isLoading}
                  >
                    <RotateCcw className="w-5 h-5" />
                    Retake
                  </button>
                  <button
                    onClick={confirmVideo}
                    className="px-6 py-3 bg-gradient-to-r from-coral-500 to-coral-600 text-white rounded-full font-semibold hover:from-coral-600 hover:to-coral-700 transition-colors flex items-center gap-2"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <Loader className="w-5 h-5 animate-spin" />
                    ) : (
                      <Check className="w-5 h-5" />
                    )}
                    Use This
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Record Button */}
        {!showPreview && !isRecording && cameraReady && (
          <div className="flex justify-center mt-8">
            <button
              onClick={startRecording}
              className="w-20 h-20 bg-gradient-to-r from-coral-500 to-coral-600 rounded-full flex items-center justify-center hover:from-coral-600 hover:to-coral-700 transition-all duration-200 shadow-2xl transform hover:scale-110"
            >
              <div className="w-16 h-16 bg-white rounded-full"></div>
            </button>
          </div>
        )}

        {/* Upload Button */}
        {!showPreview && !isRecording && cameraReady && (
          <div className="flex justify-center mt-4">
            <button
              onClick={openUploadPicker}
              className="px-6 py-3 bg-white/10 backdrop-blur text-white rounded-full font-semibold hover:bg-white/20 transition-colors flex items-center gap-2"
            >
              <Upload className="w-5 h-5" />
              Upload a Memory
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="video/*"
              className="hidden"
              onChange={onUploadFileSelected}
            />
          </div>
        )}

        {/* Instructions */}
        {!showPreview && !isRecording && cameraReady && (
          <p className="text-center text-white/60 mt-4">
            Tap to start recording your 10-second memory
          </p>
        )}
        
        {/* Loading Camera */}
        {!cameraReady && cameraPermission !== 'denied' && !showPreview && (
          <div className="flex justify-center mt-8">
            <Loader className="w-8 h-8 text-white animate-spin" />
          </div>
        )}
      </div>
    </div>
  );
};

export default MemoryCapture;