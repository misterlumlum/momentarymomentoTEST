import React from 'react';

interface HourglassLogoProps {
  className?: string;
}

const HourglassLogo: React.FC<HourglassLogoProps> = ({ className = "w-8 h-8" }) => {
  return (
    <svg 
      viewBox="0 0 512 512" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="32" 
      strokeLinecap="round" 
      strokeLinejoin="round"
      className={className}
    >
      {/* Top rim with gap */}
      <line x1="100" y1="32" x2="216" y2="32" />
      <line x1="296" y1="32" x2="412" y2="32" />
      
      {/* Bottom rim with gap */}
      <line x1="100" y1="480" x2="216" y2="480" />
      <line x1="296" y1="480" x2="412" y2="480" />
      
      {/* Left M - top part */}
      <path d="M 116 32 Q 116 80, 116 120 Q 116 180, 180 240 Q 210 256, 216 256" />
      
      {/* Right M - top part */}
      <path d="M 396 32 Q 396 80, 396 120 Q 396 180, 332 240 Q 302 256, 296 256" />
      
      {/* Left M - bottom part */}
      <path d="M 216 256 Q 210 256, 180 272 Q 116 332, 116 392 Q 116 432, 116 480" />
      
      {/* Right M - bottom part */}
      <path d="M 296 256 Q 302 256, 332 272 Q 396 332, 396 392 Q 396 432, 396 480" />

    </svg>
  );
};

export default HourglassLogo;
