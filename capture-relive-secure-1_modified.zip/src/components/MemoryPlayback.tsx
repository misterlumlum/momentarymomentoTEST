import React, { useState, useEffect, useRef } from 'react';
import { X, Heart, Trash2, ThumbsDown, Tag, RotateCcw, Shuffle, Play, Pause, Loader } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import TagSelector from './TagSelector';

interface MemoryPlaybackProps {
  memories: any[];
  onBack: () => void;
}

const MemoryPlayback: React.FC<MemoryPlaybackProps> = ({ memories, onBack }) => {
  const [currentMemory, setCurrentMemory] = useState<any>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showPreview, setShowPreview] = useState(true);
  const [memoryWeights, setMemoryWeights] = useState<{[key: string]: number}>({});
  const [isLoading, setIsLoading] = useState(false);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [tagNames, setTagNames] = useState<{[key: string]: string}>({});
  const [showRetagModal, setShowRetagModal] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);



  const { toast } = useToast();

  // Minimum swipe distance (in px)
  const minSwipeDistance = 50;


  useEffect(() => {
    if (memories.length > 0) {
      fetchTagNames();
      loadMemoryWeights();
      selectRandomMemory();
    }
  }, [memories]);

  const fetchTagNames = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      // Fetch all tags (default and user-specific)
      const { data, error } = await supabase
        .from('tags')
        .select('id, name')
        .or(`user_id.is.null${user ? `,user_id.eq.${user.id}` : ''}`);

      if (error) throw error;
      
      // Create lookup map for tag ID -> tag name
      const tagMap: {[key: string]: string} = {};
      data?.forEach(tag => {
        tagMap[tag.id] = tag.name;
      });
      setTagNames(tagMap);
    } catch (error) {
      console.error('Error fetching tag names:', error);
    }
  };




  const loadMemoryWeights = async () => {
    // Load weights from memory_metrics table
    const weights: {[key: string]: number} = {};
    memories.forEach(memory => {
      const metrics = memory.memory_metrics?.[0];
      if (metrics) {
        weights[memory.id] = metrics.weight || 1;
      } else {
        weights[memory.id] = 1;
      }
    });
    setMemoryWeights(weights);
  };

  const selectRandomMemory = () => {
    if (memories.length === 0) return;
    
    const weightedMemories = memories.flatMap(m => 
      Array(Math.max(1, memoryWeights[m.id] || 1)).fill(m)
    );
    const randomIndex = Math.floor(Math.random() * weightedMemories.length);
    setCurrentMemory(weightedMemories[randomIndex]);
    setShowPreview(true);
    setIsPlaying(false);
  };

  const goToNextMemory = () => {
    if (memories.length === 0) return;
    const nextIndex = (currentIndex + 1) % memories.length;
    setCurrentIndex(nextIndex);
    setCurrentMemory(memories[nextIndex]);
    setShowPreview(true);
    setIsPlaying(false);
  };

  const goToPreviousMemory = () => {
    if (memories.length === 0) return;
    const prevIndex = currentIndex === 0 ? memories.length - 1 : currentIndex - 1;
    setCurrentIndex(prevIndex);
    setCurrentMemory(memories[prevIndex]);
    setShowPreview(true);
    setIsPlaying(false);
  };

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    
    if (isLeftSwipe) {
      goToNextMemory();
    }
    if (isRightSwipe) {
      goToPreviousMemory();
    }
  };


  const handleAction = async (action: string) => {
    if (!currentMemory) return;
    
    setIsLoading(true);
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');
      
      switch(action) {
        case 'favorite':
          // Update weight and favorite count
          await supabase
            .from('memory_metrics')
            .upsert({
              memory_id: currentMemory.id,
              user_id: user.id,
              weight: (memoryWeights[currentMemory.id] || 1) + 2,
              favorite_count: (currentMemory.memory_metrics?.[0]?.favorite_count || 0) + 1
            });
          setMemoryWeights(prev => ({ ...prev, [currentMemory.id]: (prev[currentMemory.id] || 1) + 2 }));
          toast({ title: "Added to favorites!", description: "You'll see this memory more often" });
          break;
          
        case 'delete':
          // Delete the memory
          await supabase
            .from('memories')
            .delete()
            .eq('id', currentMemory.id);
          
          // Remove from local memories array
          const index = memories.findIndex(m => m.id === currentMemory.id);
          if (index > -1) {
            memories.splice(index, 1);
          }
          
          toast({ title: "Memory deleted", description: "This memory has been removed" });
          break;
          
        case 'seeLess':
          // Decrease weight
          const newWeight = Math.max(0, (memoryWeights[currentMemory.id] || 1) - 1);
          await supabase
            .from('memory_metrics')
            .upsert({
              memory_id: currentMemory.id,
              user_id: user.id,
              weight: newWeight,
              skip_count: (currentMemory.memory_metrics?.[0]?.skip_count || 0) + 1
            });
          setMemoryWeights(prev => ({ ...prev, [currentMemory.id]: newWeight }));
          toast({ title: "Got it!", description: "You'll see this memory less often" });
          break;

        case 'retag':
          // Open tag selector modal
          setIsLoading(false);
          setShowRetagModal(true);
          return; // Don't load next memory yet

          
        case 'sendBack':
          // Neutral action - just update view count
          await supabase
            .from('memory_metrics')
            .upsert({
              memory_id: currentMemory.id,
              user_id: user.id,
              view_count: (currentMemory.memory_metrics?.[0]?.view_count || 0) + 1
            });
          break;
      }
      
      // Load next memory after a short delay
      setTimeout(() => selectRandomMemory(), 500);
      
    } catch (error) {
      console.error('Error handling action:', error);
      toast({
        title: "Error",
        description: "Failed to update memory",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const startPlayback = () => {
    setShowPreview(false);
    setIsPlaying(true);
    if (videoRef.current) {
      videoRef.current.play();
    }
  };

  const togglePlayback = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} week${Math.floor(diffDays / 7) > 1 ? 's' : ''} ago`;
    return `${Math.floor(diffDays / 30)} month${Math.floor(diffDays / 30) > 1 ? 's' : ''} ago`;

  };

  const handleRetagSave = async (newTags: string[]) => {
    if (!currentMemory) return;
    
    try {
      const { error } = await supabase
        .from('memories')
        .update({ tags: newTags })
        .eq('id', currentMemory.id);
      
      if (error) throw error;
      
      // Update local memory
      currentMemory.tags = newTags;
      
      toast({ 
        title: "Tags updated!", 
        description: "Memory has been retagged successfully" 
      });
      
      setShowRetagModal(false);
      setTimeout(() => selectRandomMemory(), 500);
    } catch (error) {
      console.error('Error updating tags:', error);
      toast({
        title: "Error",
        description: "Failed to update tags",
        variant: "destructive"
      });
    }
  };



  if (memories.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-gray-800 text-xl mb-4">No memories to relive yet</p>
          <button
            onClick={onBack}
            className="px-6 py-3 bg-coral-500 text-white rounded-full font-semibold hover:bg-coral-600 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="p-3 bg-gray-800/80 backdrop-blur rounded-full hover:bg-gray-900 transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
          
          <h1 className="text-2xl font-bold text-gray-800">Relive Memory</h1>
          
          <button
            onClick={selectRandomMemory}
            className="p-3 bg-gray-800/80 backdrop-blur rounded-full hover:bg-gray-900 transition-colors"
          >
            <Shuffle className="w-6 h-6 text-white" />
          </button>
        </div>


        {/* Memory Player */}
        <div 
          className="relative bg-black rounded-3xl overflow-hidden aspect-[9/16] max-h-[60vh] mx-auto"
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >

          {showPreview && currentMemory ? (
            <>
              {/* Preview Overlay */}
              <div 
                className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-700/90 to-pink-500/90"
              >

                <div className="text-center text-white p-8">
                  <p className="text-lg mb-2 opacity-80">You're about to relive:</p>
                  <div className="flex justify-center gap-2 mb-6">
                    {currentMemory.tags?.map((tagId: string, i: number) => (
                      <span key={i} className="px-3 py-1 bg-white/20 backdrop-blur rounded-full text-sm">
                        {tagNames[tagId] || tagId}
                      </span>
                    ))}

                  </div>
                  <p className="text-sm opacity-60 mb-8">{formatDate(currentMemory.created_at)}</p>
                  
                  <button
                    onClick={startPlayback}
                    className="w-20 h-20 bg-white/20 backdrop-blur rounded-full flex items-center justify-center mx-auto hover:bg-white/30 transition-colors"
                  >
                    <Play className="w-10 h-10 text-white ml-1" />
                  </button>
                </div>
              </div>
            </>

          ) : currentMemory ? (
            <>
              {/* Video Playback */}
              <video
                ref={videoRef}
                src={currentMemory.video_url}
                autoPlay
                loop
                playsInline
                className="absolute inset-0 w-full h-full object-cover"
                onEnded={() => setIsPlaying(false)}
              />
              
              {/* Playback Controls */}
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <button
                  onClick={togglePlayback}
                  className="absolute bottom-4 right-4 p-3 bg-white/20 backdrop-blur rounded-full hover:bg-white/30 transition-colors"
                >
                  {isPlaying ? (
                    <Pause className="w-6 h-6 text-white" />
                  ) : (
                    <Play className="w-6 h-6 text-white" />
                  )}
                </button>
              </div>
            </>
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <Loader className="w-8 h-8 text-white animate-spin" />
            </div>
          )}
        </div>

        {/* Action Buttons */}
        {!showPreview && currentMemory && (
          <div className="flex justify-center gap-3 mt-8">
            <button
              onClick={() => handleAction('favorite')}
              disabled={isLoading}
              className="p-4 bg-pink-500/20 backdrop-blur rounded-full hover:bg-pink-500/30 transition-colors group disabled:opacity-50"
              title="Favorite (+2 weight)"
            >
              <Heart className="w-6 h-6 text-pink-400 group-hover:scale-110 transition-transform" />
            </button>
            
            <button
              onClick={() => handleAction('delete')}
              disabled={isLoading}
              className="p-4 bg-red-500/20 backdrop-blur rounded-full hover:bg-red-500/30 transition-colors group disabled:opacity-50"
              title="Delete"
            >
              <Trash2 className="w-6 h-6 text-red-400 group-hover:scale-110 transition-transform" />
            </button>
            
            <button
              onClick={() => handleAction('seeLess')}
              disabled={isLoading}
              className="p-4 bg-orange-500/20 backdrop-blur rounded-full hover:bg-orange-500/30 transition-colors group disabled:opacity-50"
              title="See Less (-1 weight)"
            >
              <ThumbsDown className="w-6 h-6 text-orange-400 group-hover:scale-110 transition-transform" />
            </button>
            
            <button
              onClick={() => handleAction('retag')}
              disabled={isLoading}
              className="p-4 bg-blue-500/20 backdrop-blur rounded-full hover:bg-blue-500/30 transition-colors group disabled:opacity-50"
              title="Retag"
            >
              <Tag className="w-6 h-6 text-blue-400 group-hover:scale-110 transition-transform" />
            </button>
            
            <button
              onClick={() => handleAction('sendBack')}
              disabled={isLoading}
              className="p-4 bg-gray-500/20 backdrop-blur rounded-full hover:bg-gray-500/30 transition-colors group disabled:opacity-50"
              title="Send Back"
            >
              <RotateCcw className="w-6 h-6 text-gray-400 group-hover:scale-110 transition-transform" />
            </button>
          </div>
        )}

        {/* Action Labels */}
        {!showPreview && currentMemory && (
          <div className="flex justify-center gap-8 mt-4 text-xs text-gray-600">
            <span>Favorite</span>
            <span>Delete</span>
            <span>See Less</span>
            <span>Retag</span>
            <span>Send Back</span>
          </div>
        )}
      </div>

      {/* Retag Modal */}
      {/* Retag Modal */}
      {showRetagModal && currentMemory && (
        <div className="fixed inset-0 z-50">
          <TagSelector
            onSelect={handleRetagSave}
            onBack={() => setShowRetagModal(false)}
            buttonText="Done"
            initialTags={currentMemory.tags || []}
          />
        </div>
      )}

    </div>

  );
};

export default MemoryPlayback;
